rootProject.name = "MKVEditor"
include(":app")