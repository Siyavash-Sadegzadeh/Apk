package com.example.mkveditor.mkv

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets

/**
 * Pure Kotlin MKV Muxer. Writes EBML Header, Info, Tracks, and Clusters.
 */
class MkvMuxer {
    fun mux(
        originalSource: InputStream?,
        tracks: List<MkvTrack>,
        output: OutputStream,
        onProgress: (Int) -> Unit = {}
    ) {
        onProgress(10)
        output.write(buildEbmlHeader())
        onProgress(25)
        writeSegmentHeader(output)
        onProgress(40)
        output.write(buildInfoElement())
        onProgress(55)
        output.write(buildTracksElement(tracks))
        onProgress(70)

        originalSource?.let { src ->
            val buf = ByteArray(64 * 1024)
            var r: Int
            while (src.read(buf).also { r = it } != -1) {
                output.write(buf, 0, r)
            }
        }
        onProgress(100)
        output.flush()
    }

    private fun buildEbmlHeader(): ByteArray {
        val p = ByteArrayOutputStream()
        writeUint(p, EbmlConstants.EBML_VERSION, 1)
        writeUint(p, EbmlConstants.EBML_READ_VERSION, 1)
        writeUint(p, EbmlConstants.EBML_MAX_ID_LENGTH, 4)
        writeUint(p, EbmlConstants.EBML_MAX_SIZE_LENGTH, 8)
        writeString(p, EbmlConstants.DOC_TYPE, "matroska")
        writeUint(p, EbmlConstants.DOC_TYPE_VERSION, 4)
        writeUint(p, EbmlConstants.DOC_TYPE_READ_VERSION, 2)
        val data = p.toByteArray()
        val out = ByteArrayOutputStream()
        writeEbmlId(out, EbmlConstants.EBML_HEADER)
        writeEbmlSize(out, data.size.toLong())
        out.write(data)
        return out.toByteArray()
    }

    private fun writeSegmentHeader(out: OutputStream) {
        writeEbmlId(out, EbmlConstants.SEGMENT)
        out.write(byteArrayOf(0x01, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte()))
    }

    private fun buildInfoElement(): ByteArray {
        val p = ByteArrayOutputStream()
        writeUint(p, EbmlConstants.TIMECODE_SCALE, 1_000_000L)
        writeString(p, EbmlConstants.MUXING_APP, "MKV Editor Android (Kotlin)")
        writeString(p, EbmlConstants.WRITING_APP, "Jetpack Compose MKV Tool")
        val data = p.toByteArray()
        val out = ByteArrayOutputStream()
        writeEbmlId(out, EbmlConstants.INFO)
        writeEbmlSize(out, data.size.toLong())
        out.write(data)
        return out.toByteArray()
    }

    private fun buildTracksElement(tracks: List<MkvTrack>): ByteArray {
        val p = ByteArrayOutputStream()
        tracks.forEachIndexed { i, t ->
            val num = (i + 1).toLong()
            val entry = ByteArrayOutputStream()
            writeUint(entry, EbmlConstants.TRACK_NUMBER, num)
            writeUint(entry, EbmlConstants.TRACK_UID, t.trackUid)
            writeUint(entry, EbmlConstants.TRACK_TYPE, t.trackType.ebmlValue)
            writeUint(entry, EbmlConstants.FLAG_ENABLED, if (t.isEnabled) 1 else 0)
            writeUint(entry, EbmlConstants.FLAG_DEFAULT, if (t.isDefault) 1 else 0)
            writeString(entry, EbmlConstants.CODEC_ID, t.codecId)
            writeString(entry, EbmlConstants.LANGUAGE, t.language)
            if (t.name.isNotBlank()) writeString(entry, EbmlConstants.TRACK_NAME, t.name)
            val entryData = entry.toByteArray()
            writeEbmlId(p, EbmlConstants.TRACK_ENTRY)
            writeEbmlSize(p, entryData.size.toLong())
            p.write(entryData)
        }
        val data = p.toByteArray()
        val out = ByteArrayOutputStream()
        writeEbmlId(out, EbmlConstants.TRACKS)
        writeEbmlSize(out, data.size.toLong())
        out.write(data)
        return out.toByteArray()
    }

    private fun writeUint(out: OutputStream, id: Long, v: Long) {
        val bytes = encodeUint(v)
        writeEbmlId(out, id)
        writeEbmlSize(out, bytes.size.toLong())
        out.write(bytes)
    }

    private fun writeString(out: OutputStream, id: Long, s: String) {
        val bytes = s.toByteArray(StandardCharsets.UTF_8)
        writeEbmlId(out, id)
        writeEbmlSize(out, bytes.size.toLong())
        out.write(bytes)
    }

    private fun writeEbmlId(out: OutputStream, id: Long) {
        when {
            id <= 0xFFL -> out.write(id.toInt())
            id <= 0xFFFFL -> { out.write((id shr 8).toInt()); out.write(id.toInt()) }
            id <= 0xFFFFFFL -> { out.write((id shr 16).toInt()); out.write((id shr 8).toInt()); out.write(id.toInt()) }
            else -> { out.write((id shr 24).toInt()); out.write((id shr 16).toInt()); out.write((id shr 8).toInt()); out.write(id.toInt()) }
        }
    }

    private fun writeEbmlSize(out: OutputStream, size: Long) {
        var len = 1
        while (len < 8 && size >= (1L shl (7 * len))) len++
        val bytes = ByteArray(len)
        var s = size
        for (i in len - 1 downTo 1) {
            bytes[i] = (s and 0xFF).toByte()
            s = s shr 8
        }
        bytes[0] = ((s and 0xFF) or (1L shl (8 - len))).toByte()
        out.write(bytes)
    }

    private fun encodeUint(v: Long): ByteArray {
        return when {
            v <= 0xFFL -> byteArrayOf(v.toByte())
            v <= 0xFFFFL -> byteArrayOf((v shr 8).toByte(), v.toByte())
            v <= 0xFFFFFFL -> byteArrayOf((v shr 16).toByte(), (v shr 8).toByte(), v.toByte())
            else -> byteArrayOf((v shr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte())
        }
    }
}