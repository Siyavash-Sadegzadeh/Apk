package com.example.mkveditor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.mkveditor.ui.FileBrowserScreen
import com.example.mkveditor.ui.HomeScreen
import com.example.mkveditor.ui.theme.MKVEditorTheme
import com.example.mkveditor.viewmodel.FileBrowserPurpose
import com.example.mkveditor.viewmodel.MkvEditorViewModel
import com.example.mkveditor.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val viewModel: MkvEditorViewModel by viewModels()

    // SAF Tree Picker Launcher (ACTION_OPEN_DOCUMENT_TREE)
    // User chooses a folder on device, app takes persistable URI permission
    private val openDocumentTreeLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) {
            viewModel.onSafFolderSelected(treeUri)
        }
    }

    // SAF Save Picker Launcher (ACTION_CREATE_DOCUMENT)
    // User chooses destination to write exported MKV container
    private val createDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("video/x-matroska")
    ) { targetUri ->
        if (targetUri != null) {
            viewModel.exportToSafUri(targetUri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MKVEditorTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val currentScreen by viewModel.currentScreen.collectAsState()
                    val browserPurpose by viewModel.browserPurpose.collectAsState()
                    val breadcrumbs by viewModel.breadcrumbs.collectAsState()
                    val browserItems by viewModel.browserItems.collectAsState()
                    val metadata by viewModel.currentMetadata.collectAsState()
                    val isLoading by viewModel.isLoading.collectAsState()
                    val isExporting by viewModel.isExporting.collectAsState()
                    val exportProgress by viewModel.exportProgress.collectAsState()
                    val statusMessage by viewModel.statusMessage.collectAsState()

                    when (currentScreen) {
                        Screen.HOME -> {
                            HomeScreen(
                                metadata = metadata,
                                isLoading = isLoading,
                                isExporting = isExporting,
                                exportProgress = exportProgress,
                                statusMessage = statusMessage,
                                onOpenMkvClick = { viewModel.openFileBrowser(FileBrowserPurpose.OPEN_MKV) },
                                onAddTrackClick = { viewModel.openFileBrowser(FileBrowserPurpose.ADD_TRACK) },
                                onExportToPrivateClick = { viewModel.exportToPrivateDirectory() },
                                onExportToSafClick = {
                                    val fileName = metadata?.fileName ?: "edited_video.mkv"
                                    createDocumentLauncher.launch(fileName)
                                },
                                onUpdateTrackLanguage = { trackId, lang -> viewModel.updateTrackLanguage(trackId, lang) },
                                onUpdateTrackName = { trackId, name -> viewModel.updateTrackName(trackId, name) },
                                onDeleteTrack = { trackId -> viewModel.deleteTrack(trackId) },
                                onDismissStatus = { viewModel.clearStatus() }
                            )
                        }

                        Screen.FILE_BROWSER -> {
                            BackHandler {
                                viewModel.navigateBack()
                            }

                            FileBrowserScreen(
                                purpose = browserPurpose,
                                breadcrumbs = breadcrumbs,
                                items = browserItems,
                                onNavigateBack = { viewModel.navigateBack() },
                                onBreadcrumbClick = { index -> viewModel.navigateToBreadcrumb(index) },
                                onItemClick = { item -> viewModel.navigateInto(item) },
                                onBrowseDeviceStorageClick = {
                                    // Launch Storage Access Framework tree picker
                                    openDocumentTreeLauncher.launch(null)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}