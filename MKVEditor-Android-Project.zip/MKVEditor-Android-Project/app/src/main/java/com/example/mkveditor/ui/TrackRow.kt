package com.example.mkveditor.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.mkveditor.mkv.LanguageDictionary
import com.example.mkveditor.mkv.MkvTrack

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackRow(
    track: MkvTrack,
    onLanguageChange: (String) -> Unit,
    onNameChange: (String) -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Track #${track.trackNumber} • ${track.trackType.displayName} (${track.codecId})")
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }, modifier = Modifier.weight(0.45f)) {
                    OutlinedTextField(
                        value = track.language,
                        onValueChange = onLanguageChange,
                        label = { Text("Language") },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        LanguageDictionary.COMMON_LANGUAGES.forEach { lang ->
                            DropdownMenuItem(text = { Text("${lang.code} - ${lang.name}") }, onClick = {
                                onLanguageChange(lang.code)
                                expanded = false
                            })
                        }
                    }
                }
                OutlinedTextField(
                    value = track.name,
                    onValueChange = onNameChange,
                    label = { Text("Track Name / Tag") },
                    modifier = Modifier.weight(0.55f)
                )
            }
        }
    }
}