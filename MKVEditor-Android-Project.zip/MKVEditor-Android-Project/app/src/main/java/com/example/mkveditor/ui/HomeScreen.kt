package com.example.mkveditor.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.mkveditor.mkv.MkvFileMetadata
import com.example.mkveditor.saf.StorageAccessHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    metadata: MkvFileMetadata?,
    isLoading: Boolean,
    isExporting: Boolean,
    exportProgress: Int,
    statusMessage: String?,
    onOpenMkvClick: () -> Unit,
    onAddTrackClick: () -> Unit,
    onExportToPrivateClick: () -> Unit,
    onExportToSafClick: () -> Unit,
    onUpdateTrackLanguage: (Long, String) -> Unit,
    onUpdateTrackName: (Long, String) -> Unit,
    onDeleteTrack: (Long) -> Unit,
    onDismissStatus: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MKV Editor") },
                actions = {
                    FilledTonalButton(onClick = onOpenMkvClick, modifier = Modifier.padding(end = 8.dp)) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Open MKV")
                    }
                }
            )
        },
        floatingActionButton = {
            if (metadata != null) {
                ExtendedFloatingActionButton(
                    onClick = onAddTrackClick,
                    icon = { Icon(Icons.Default.Add, null) },
                    text = { Text("Add Track") }
                )
            }
        }
    ) { padding ->
        if (metadata == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Button(onClick = onOpenMkvClick) { Text("Open MKV Container") }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding)) {
                item {
                    Card(Modifier.fillMaxWidth().padding(16.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(metadata.fileName, style = MaterialTheme.typography.titleLarge)
                            Text("Size: ${StorageAccessHelper.formatFileSize(metadata.fileSize)}")
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = onExportToSafClick) { Text("Save to device (SAF)") }
                                OutlinedButton(onClick = onExportToPrivateClick) { Text("Save to private") }
                            }
                        }
                    }
                }
                items(metadata.tracks, key = { it.trackNumber }) { track ->
                    TrackRow(
                        track = track,
                        onLanguageChange = { onUpdateTrackLanguage(track.trackNumber, it) },
                        onNameChange = { onUpdateTrackName(track.trackNumber, it) },
                        onDelete = { onDeleteTrack(track.trackNumber) }
                    )
                }
            }
        }
    }
}