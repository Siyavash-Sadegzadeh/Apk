package com.example.mkveditor.mkv

import java.io.ByteArrayInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets

/**
 * Pure Kotlin EBML & Matroska parser. Reads streams from SAF URIs without MediaExtractor.
 */
class MkvParser {
    data class EbmlElementHeader(val id: Long, val size: Long, val headerLength: Int)

    fun parse(
        inputStream: InputStream,
        fileName: String,
        fileSize: Long,
        uriString: String
    ): MkvFileMetadata {
        val metadata = MkvFileMetadata(fileName = fileName, fileSize = fileSize, uriString = uriString)
        var timecodeScale = 1_000_000L
        var rawDuration: Double? = null

        try {
            val ebmlHeader = readElementHeader(inputStream) ?: return metadata
            if (ebmlHeader.id != EbmlConstants.EBML_HEADER) return metadata
            skipBytes(inputStream, ebmlHeader.size)

            val segmentHeader = readElementHeader(inputStream) ?: return metadata
            if (segmentHeader.id != EbmlConstants.SEGMENT) return metadata

            while (true) {
                val header = readElementHeader(inputStream) ?: break
                when (header.id) {
                    EbmlConstants.INFO -> {
                        val infoBytes = readExact(inputStream, header.size.toInt())
                        parseInfo(infoBytes) { tcScale, dur ->
                            timecodeScale = tcScale ?: timecodeScale
                            rawDuration = dur
                        }
                    }
                    EbmlConstants.TRACKS -> {
                        val tracksBytes = readExact(inputStream, header.size.toInt())
                        val parsedTracks = parseTracks(tracksBytes)
                        metadata.tracks.clear()
                        metadata.tracks.addAll(parsedTracks)
                        break
                    }
                    EbmlConstants.CLUSTER -> break
                    else -> skipBytes(inputStream, header.size)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (rawDuration != null) {
            val durationSec = (rawDuration!! * timecodeScale) / 1_000_000_000.0
            return metadata.copy(durationSeconds = durationSec)
        }
        return metadata
    }

    private fun parseInfo(data: ByteArray, onParsed: (Long?, Double?) -> Unit) {
        val stream = ByteArrayInputStream(data)
        var tcScale: Long? = null
        var dur: Double? = null
        while (stream.available() > 0) {
            val h = readElementHeader(stream) ?: break
            when (h.id) {
                EbmlConstants.TIMECODE_SCALE -> tcScale = readUint(stream, h.size.toInt())
                EbmlConstants.DURATION -> dur = readFloat(stream, h.size.toInt())
                else -> skipBytes(stream, h.size)
            }
        }
        onParsed(tcScale, dur)
    }

    private fun parseTracks(data: ByteArray): List<MkvTrack> {
        val tracks = mutableListOf<MkvTrack>()
        val stream = ByteArrayInputStream(data)
        while (stream.available() > 0) {
            val h = readElementHeader(stream) ?: break
            if (h.id == EbmlConstants.TRACK_ENTRY) {
                parseTrackEntry(readExact(stream, h.size.toInt()))?.let { tracks.add(it) }
            } else {
                skipBytes(stream, h.size)
            }
        }
        return tracks
    }

    private fun parseTrackEntry(data: ByteArray): MkvTrack? {
        val stream = ByteArrayInputStream(data)
        var trackNumber = 1L
        var trackUid = 0L
        var trackTypeVal = 1L
        var codecId = ""
        var language = "und"
        var trackName = ""
        var videoWidth: Long? = null
        var videoHeight: Long? = null
        var audioChannels: Long? = null
        var audioSamplingRate: Double? = null

        while (stream.available() > 0) {
            val h = readElementHeader(stream) ?: break
            when (h.id) {
                EbmlConstants.TRACK_NUMBER -> trackNumber = readUint(stream, h.size.toInt())
                EbmlConstants.TRACK_UID -> trackUid = readUint(stream, h.size.toInt())
                EbmlConstants.TRACK_TYPE -> trackTypeVal = readUint(stream, h.size.toInt())
                EbmlConstants.CODEC_ID -> codecId = readString(stream, h.size.toInt())
                EbmlConstants.LANGUAGE -> language = readString(stream, h.size.toInt())
                EbmlConstants.TRACK_NAME -> trackName = readString(stream, h.size.toInt())
                EbmlConstants.VIDEO_SETTINGS -> {
                    val vStream = ByteArrayInputStream(readExact(stream, h.size.toInt()))
                    while (vStream.available() > 0) {
                        val vh = readElementHeader(vStream) ?: break
                        if (vh.id == EbmlConstants.PIXEL_WIDTH) videoWidth = readUint(vStream, vh.size.toInt())
                        else if (vh.id == EbmlConstants.PIXEL_HEIGHT) videoHeight = readUint(vStream, vh.size.toInt())
                        else skipBytes(vStream, vh.size)
                    }
                }
                EbmlConstants.AUDIO_SETTINGS -> {
                    val aStream = ByteArrayInputStream(readExact(stream, h.size.toInt()))
                    while (aStream.available() > 0) {
                        val ah = readElementHeader(aStream) ?: break
                        if (ah.id == EbmlConstants.CHANNELS) audioChannels = readUint(aStream, ah.size.toInt())
                        else if (ah.id == EbmlConstants.SAMPLING_FREQ) audioSamplingRate = readFloat(aStream, ah.size.toInt())
                        else skipBytes(aStream, ah.size)
                    }
                }
                else -> skipBytes(stream, h.size)
            }
        }

        return MkvTrack(
            trackNumber = trackNumber,
            trackUid = if (trackUid != 0L) trackUid else trackNumber,
            trackType = TrackType.fromValue(trackTypeVal),
            codecId = codecId.ifEmpty { "V_MPEG4/ISO/AVC" },
            language = language.ifBlank { "und" },
            name = trackName,
            videoWidth = videoWidth,
            videoHeight = videoHeight,
            audioChannels = audioChannels,
            audioSamplingRate = audioSamplingRate
        )
    }

    private fun readElementHeader(stream: InputStream): EbmlElementHeader? {
        val id = readVint(stream, true) ?: return null
        val size = readVint(stream, false) ?: return null
        return EbmlElementHeader(id.first, size.first, id.second + size.second)
    }

    private fun readVint(stream: InputStream, isId: Boolean): Pair<Long, Int>? {
        val first = stream.read()
        if (first == -1) return null
        var mask = 0x80
        var len = 1
        while (mask > 0 && (first and mask) == 0) {
            mask = mask shr 1
            len++
        }
        var value = if (isId) first.toLong() else (first and (mask - 1)).toLong()
        for (i in 1 until len) {
            val b = stream.read()
            if (b == -1) return null
            value = (value shl 8) or (b.toLong() and 0xFF)
        }
        return Pair(value, len)
    }

    private fun readUint(stream: InputStream, len: Int): Long {
        var v = 0L
        for (i in 0 until len) {
            val b = stream.read()
            if (b == -1) break
            v = (v shl 8) or (b.toLong() and 0xFF)
        }
        return v
    }

    private fun readFloat(stream: InputStream, len: Int): Double {
        val bytes = readExact(stream, len)
        val buf = ByteBuffer.wrap(bytes)
        return if (len == 4) buf.float.toDouble() else if (len == 8) buf.double else 0.0
    }

    private fun readString(stream: InputStream, len: Int): String {
        return String(readExact(stream, len), StandardCharsets.UTF_8).trimEnd { it == '\u0000' }
    }

    private fun readExact(stream: InputStream, len: Int): ByteArray {
        val buf = ByteArray(len)
        var total = 0
        while (total < len) {
            val r = stream.read(buf, total, len - total)
            if (r == -1) break
            total += r
        }
        return buf
    }

    private fun skipBytes(stream: InputStream, count: Long) {
        var rem = count
        while (rem > 0) {
            val s = stream.skip(rem)
            if (s <= 0) {
                if (stream.read() == -1) break
                rem -= 1
            } else rem -= s
        }
    }
}