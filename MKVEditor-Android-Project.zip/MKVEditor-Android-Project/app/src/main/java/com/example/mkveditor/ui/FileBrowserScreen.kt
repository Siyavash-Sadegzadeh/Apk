package com.example.mkveditor.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.mkveditor.saf.StorageAccessHelper
import com.example.mkveditor.saf.StorageAccessHelper.FileBrowserItem
import com.example.mkveditor.viewmodel.FileBrowserPurpose

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileBrowserScreen(
    purpose: FileBrowserPurpose,
    breadcrumbs: List<FileBrowserItem>,
    items: List<FileBrowserItem>,
    onNavigateBack: () -> Unit,
    onBreadcrumbClick: (Int) -> Unit,
    onItemClick: (FileBrowserItem) -> Unit,
    onBrowseDeviceStorageClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (purpose == FileBrowserPurpose.OPEN_MKV) "Open MKV File" else "Select Track File") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    FilledTonalButton(onClick = onBrowseDeviceStorageClick, modifier = Modifier.padding(end = 8.dp)) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Browse device storage")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Breadcrumbs bar
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(12.dp)) {
                TextButton(onClick = { onBreadcrumbClick(-1) }) { Text("Storage Roots") }
                breadcrumbs.forEachIndexed { i, crumb ->
                    Text(" / ", modifier = Modifier.align(Alignment.CenterVertically))
                    TextButton(onClick = { onBreadcrumbClick(i) }) { Text(crumb.displayName) }
                }
            }
            HorizontalDivider()
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(items, key = { it.id }) { item ->
                    ListItem(
                        modifier = Modifier.clickable { onItemClick(item) },
                        leadingContent = {
                            Icon(if (item.isDirectory) Icons.Default.Folder else Icons.Default.Movie, contentDescription = null)
                        },
                        headlineContent = { Text(item.displayName) },
                        supportingContent = {
                            Text(if (item.isDirectory) "Folder" else StorageAccessHelper.formatFileSize(item.sizeBytes))
                        }
                    )
                }
            }
        }
    }
}