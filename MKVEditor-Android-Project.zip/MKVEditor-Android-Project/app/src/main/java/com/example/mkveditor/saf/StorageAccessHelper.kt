package com.example.mkveditor.saf

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

/**
 * Storage Access Framework (SAF) helper. Zero MANAGE_EXTERNAL_STORAGE.
 */
object StorageAccessHelper {
    data class FileBrowserItem(
        val id: String,
        val displayName: String,
        val uri: Uri?,
        val file: File?,
        val isDirectory: Boolean,
        val sizeBytes: Long = 0L,
        val extension: String = "",
        val isSafTreeRoot: Boolean = false
    )

    fun getRootLocations(context: Context): List<FileBrowserItem> {
        val roots = mutableListOf<FileBrowserItem>()
        // 1. App Internal filesDir
        if (context.filesDir.exists()) {
            roots.add(FileBrowserItem("internal_files", "App Private Storage (filesDir)", null, context.filesDir, true))
        }
        // 2. App External getExternalFilesDir
        context.getExternalFilesDir(null)?.let {
            if (it.exists()) roots.add(FileBrowserItem("external_files", "App External Storage (Android/data/...)", null, it, true))
        }
        // 3. Persisted SAF Trees
        context.contentResolver.persistedUriPermissions.forEach { perm ->
            if (perm.isReadPermission) {
                val doc = DocumentFile.fromTreeUri(context, perm.uri)
                val name = doc?.name ?: perm.uri.lastPathSegment ?: "Persisted Storage Folder"
                roots.add(FileBrowserItem(perm.uri.toString(), "SAF: $name", perm.uri, null, true, isSafTreeRoot = true))
            }
        }
        return roots
    }

    fun persistUriPermission(context: Context, treeUri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try { context.contentResolver.takePersistableUriPermission(treeUri, flags) } catch (e: Exception) { e.printStackTrace() }
    }

    fun listDirectory(dir: File, allowed: Set<String>?): List<FileBrowserItem> {
        return (dir.listFiles() ?: emptyArray()).mapNotNull { f ->
            val ext = f.extension.lowercase()
            if (f.isDirectory) FileBrowserItem(f.absolutePath, f.name, null, f, true)
            else if (allowed == null || allowed.contains(ext)) FileBrowserItem(f.absolutePath, f.name, null, f, false, f.length(), ext)
            else null
        }.sortedWith(compareBy({ !it.isDirectory }, { it.displayName.lowercase() }))
    }

    fun listSafDirectory(context: Context, treeUri: Uri, allowed: Set<String>?): List<FileBrowserItem> {
        val doc = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
        return doc.listFiles().mapNotNull { f ->
            val name = f.name ?: "Unknown"
            val ext = name.substringAfterLast('.', "").lowercase()
            if (f.isDirectory) FileBrowserItem(f.uri.toString(), name, f.uri, null, true)
            else if (allowed == null || allowed.contains(ext)) FileBrowserItem(f.uri.toString(), name, f.uri, null, false, f.length(), ext)
            else null
        }.sortedWith(compareBy({ !it.isDirectory }, { it.displayName.lowercase() }))
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val i = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, 3)
        return String.format("%.1f %s", bytes / Math.pow(1024.0, i.toDouble()), units[i])
    }
}