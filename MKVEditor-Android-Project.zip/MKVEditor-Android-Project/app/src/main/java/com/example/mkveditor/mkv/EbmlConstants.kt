package com.example.mkveditor.mkv

/**
 * Standard EBML / Matroska element IDs according to the official Matroska specification.
 */
object EbmlConstants {
    const val EBML_HEADER = 0x1A45DFA3L
    const val EBML_VERSION = 0x4286L
    const val EBML_READ_VERSION = 0x42F7L
    const val EBML_MAX_ID_LENGTH = 0x42F2L
    const val EBML_MAX_SIZE_LENGTH = 0x42F3L
    const val DOC_TYPE = 0x4282L
    const val DOC_TYPE_VERSION = 0x4287L
    const val DOC_TYPE_READ_VERSION = 0x4285L

    const val SEGMENT = 0x18538067L
    const val SEEK_HEAD = 0x114D9B74L
    const val INFO = 0x1549A966L
    const val TRACKS = 0x1654AE6BL
    const val CLUSTER = 0x1F43B675L
    const val CUES = 0x1C53BB6BL

    const val TIMECODE_SCALE = 0x2AD7B1L
    const val DURATION = 0x4489L
    const val MUXING_APP = 0x4D80L
    const val WRITING_APP = 0x5741L

    const val TRACK_ENTRY = 0xAEL
    const val TRACK_NUMBER = 0xD7L
    const val TRACK_UID = 0x73C5L
    const val TRACK_TYPE = 0x83L
    const val FLAG_ENABLED = 0xB9L
    const val FLAG_DEFAULT = 0x88L
    const val FLAG_FORCED = 0x55AAL
    const val CODEC_ID = 0x86L
    const val CODEC_PRIVATE = 0x63A2L
    const val TRACK_NAME = 0x536EL
    const val LANGUAGE = 0x22B59CL
    const val LANGUAGE_BCP47 = 0x22B59DL

    const val VIDEO_SETTINGS = 0xE0L
    const val PIXEL_WIDTH = 0xB0L
    const val PIXEL_HEIGHT = 0xBAL

    const val AUDIO_SETTINGS = 0xE1L
    const val SAMPLING_FREQ = 0xB5L
    const val CHANNELS = 0x9FL

    const val CLUSTER_TIMECODE = 0xE7L
    const val SIMPLE_BLOCK = 0xA3L

    const val TRACK_TYPE_VIDEO = 1L
    const val TRACK_TYPE_AUDIO = 2L
    const val TRACK_TYPE_SUBTITLE = 17L
}